export default ({user}) => {
    return (
        <li>
            <div>
                <span>firstName: {user.firstName}, </span>
                <span>lastName: {user.lastName}, </span>
                <span>fullName: {user.firstName + " " + user.lastName}, </span>
                <span>age: {user.age + 5}, </span>
                <span>job: {user.job} </span>
            </div>
        </li>
    )
};